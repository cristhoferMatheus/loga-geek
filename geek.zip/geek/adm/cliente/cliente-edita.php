<?php
include_once '../classes/autoload.php';

//Verifica se veio tudo preenchido do formulário
if (isset($_GET['id']) && $_GET['id'] != "") {

    $cliente = new Cliente();
    $cliente->setId($_GET['id']);

    $clienteDao = new ClienteDao();
    $clienteData = $clienteDao->selectById($cliente);
    
}
?>

<html>
<body> 

    <section id="contato">
        <h2> Cadastre-se:</h2>
        <div class="areaform">
            <form method="post" action="cliente-edita-ok.php">
            <input type="hidden" name="id" value="<?php echo $clienteData->getId(); ?>" >
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Insira seu nome">

                <label for="Snome">Sobrenome:</label>
                <input type="text" id="Snome" name="Snome" placeholder="Insira o sobrenome">

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" placeholder="Insira seu email">

				<label for="cpf">Cpf:</label>
                <input type="number" id="cpf" name="cpf" placeholder="Insira o cpf">

                <label for="cidade">Cidade:</label>
                <input type="text" id="cidade" name="cidade" placeholder="insira a sua cidade">
				
				<label for="estado">Estado:</label>
                <input type="text" id="estado" name="estado" placeholder="insira seu estado">
				
				<label for="login">Login:</label>
                <input type="text" id="login" name="login" placeholder="insira um login">
				
				<label for="senha">Senha:</label>
                <input type="text" id="senha" name="senha" placeholder="insira uma senha">

             <button class="button" type="submit"> Confirmar</button>
            </form>
        </div>
     </section>
    
    <footer> 
   </footer>
</body>
</html>