<?php 
include_once '../classes/autoload.php';

$categoriaDao = new CategoriaDao();
$lista = $categoriaDao->select();

print_r($lista);
?>

<html>
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="assets/js/script.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"/>
        <link rel="sortcut icon" href="assets/img/icon.ico" type="image/x-icon"/>
        <meta charset="utf-8">
    <body>

    <section id="content">

            <table>
			<thead>
			<tr>
			<th>id</th>
			<th>actions figures</th>
			<th>Livros</th>
			<th>Acessorios</th>
			<th>Roupas</th>
			</tr>
			</thead>
			<tbody>
                    <?php foreach($lista as $categorias): ?>
                 
					<tr>
							<td> <?php echo $categorias->getId(); ?></td>
                            <td> <?php echo $categorias->getAction(); ?></td>
                            <td> <?php echo $categorias->getLivros(); ?></td>
                            <td> <?php echo $categorias->getAcessorios(); ?></td>
                            <td> <?php echo $categorias->getRoupas(); ?></td>
							
                        <td><button onclick="confirm('Deseja exclir este registro?') ? window.location='categoria-deleta-ok.php?id=<?php echo $categorias->getId(); ?>' : stop = false;">  excluir </button> </td>
                        <td><button  onclick="window.location='categoria-edita.php?id=<?php echo $categorias->getId(); ?>';" class="btn btn-outline btn-primary"> editar </button> </td>

                    <?php endforeach; ?> 
			</tbody>		
</table>
        </section>

    <footer>
        
    </footer>
    </body>
</html>
                                        