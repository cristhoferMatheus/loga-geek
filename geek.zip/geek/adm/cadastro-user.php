<html>
    <head></head>
    
<body> 

    <section id="contato">
        <h2> Cadastre-se:</h2>
        <div class="areaform">
            <form method="post" action="cadastro-user-ok.php"> 
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Insira seu nome">

                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" placeholder="Insira seu e-mail">

                <label for="Telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" placeholder="Insira seu número de telefone ou celular">

				<label for="endereco">endereço:</label>
                <input type="text" id="endereco" name="endereco" placeholder="Insira seu endereço">

				<label for="dtnasc">data de nascimento:</label>
                <input type="text" id="dtnasc" name="dtnasc" placeholder="Insira sua data de nascimento">

                <label for="Senha">Senha:</label>
                <input type="password" id="senha" name="senha" placeholder="Digite sua senha">

                <label for="Senha">Confirme sua senha:</label>
                <input type="password" id="senha" name="senha2" placeholder="Confirme sua senha">
             <button class="button" type="submit"> Confirmar</button>
            </form>
        </div>
     </section>
    
    <footer>  </footer>
</body>
</html>