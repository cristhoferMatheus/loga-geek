<!DOCTYPE HTML>
<html>
    <head>
        <title>Cadastro de Usuário</title>
        <meta charset="utf-8">
    </head>
    <body>
        <h1>Cadastro de Usuário</h1>
        <form action="cadastro-usuario-ok.php" method="post">
            <label>Username</label> <input type="text" name="username"></br>
            <label>Senha</label> <input type="password" name="password"></br>
            <label>E-mail</label> <input type="email" name="email"></br>
            <input type="submit" value="Cadastrar">
        </form>
    </body>
</html>