<?php
include_once '../classes/autoload.php';

if (isset($_POST['nome']) && $_POST['nome'] != "" 
        && isset($_POST['email']) && $_POST['email'] != ""
        && isset($_POST['telefone']) && $_POST['telefone'] != ""
        && isset($_POST['endereco']) && $_POST['endereco'] != ""
		&& isset($_POST['senha']) && $_POST['senha'] != "") {

    $usuario = new Usuario();
    $usuario->setId($_POST['id']);
    $usuario->setNome($_POST['nome']);
    $usuario->setEmail($_POST['email']);
    $usuario->setTelefone($_POST['telefone']);
    $usuario->setEndereco($_POST['endereco']);
	$usuario->setSenha($_POST['senha']);

    $usuarioDao = new UsuarioDao();
    $usuarioDao->update($usuario);
}
?>

<html>    
<body> 
    
    <section id="contato">
        <h2> Sucesso ao editar!</h2>
     </section>
    
</body>
    <footer> 
    </footer>
</html>