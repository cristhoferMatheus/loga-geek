<?php
include_once '../classes/autoload.php';

//Verifica se veio tudo preenchido do formulário

if (isset($_POST['nPed']) && $_POST['nPed'] != "" 
        && isset($_POST['nomeS']) && $_POST['nomeS'] != ""
        && isset($_POST['estado']) && $_POST['estado'] != ""
		&& isset($_POST['cidade']) && $_POST['cidade'] != ""
        && isset($_POST['endereco']) && $_POST['endereco'] != "") {

    $encomenda = new Encomenda();
    $encomenda->setNPed($_POST['nPed']);
    $encomenda->setNomeS($_POST['nomeS']);
    $encomenda->setEstado($_POST['estado']);
    $encomenda->setCidade($_POST['cidade']);
	$encomenda->setEndereco($_POST['endereco']); 

    $encomendaDao = new EncomendaDao();
    $b = $encomendaDao->insert($encomenda);
	
	//if($b){
	//	echo "foi";
	//} else{
	//	echo "não";
	//}
}
?>

<html>
<body> 

    <section id="contato">
        <h2> Sucesso ao cadastrar!</h2>
     </section>
    
    <footer> 
    </footer>
</body>
</html>