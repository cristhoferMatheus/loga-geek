<?php
$news = $data['noticia'];

?>
<header style="height:100px"></header>
<section class="bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto" >
                <h1 class="text-center cor">

                    <?php echo $news->getTitulo() ?></h1>
                
                 
                        <img src="<?php echo $news->getLinks(); ?>">
                        
                        </br><p><?php echo $news->getText() ?></p></br>
                        
                        <p class="text-center"><?php echo $news->getText1() ?></p>
                        
                        <center><a href="<?php echo $this->url ?>News">Voltar</a></center>
                        
                        </div>
                        
        </div>
        
    </div
    
</section>
