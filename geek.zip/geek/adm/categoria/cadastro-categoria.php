<html>
    <head></head>
    
<body> 

    <section id="contato">
        <h2> Cadastre-se:</h2>
        <div class="areaform">
            <form method="post" action="cadastro-categoria-ok.php"> 
                <label for="action">Action:</label>
                <input type="text" id="action" name="action" placeholder="Insira a action figure">

                <label for="livros">Livros:</label>
                <input type="text" id="livros" name="livros" placeholder="Insira o livro">

                <label for="acessorios">Acessorios:</label>
                <input type="textarea" id="acessorios" name="acessorios" placeholder="Insira o acessorio">

				<label for="roupas">Roupas:</label>
                <input type="text" id="roupas" name="roupas" placeholder="Insira a roupa">

             <button class="button" type="submit"> Confirmar</button>
            </form>
        </div>
     </section>
 
    <footer>  </footer>
</body>
</html>