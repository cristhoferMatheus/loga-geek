<!DOCTYPE HTML>
<html>
    <head>
        <title>Cadastro de Usuário</title>
        <meta charset="utf-8">
    </head>
    <body>
        <?php
        include_once 'classes/UsuarioDao.php';
        
        $usuarioDao = new UsuarioDao();
        $return = $usuarioDao->select();
        
        foreach ($return as $linha){
            echo $linha->getEmail() . "<br>";
        }
        ?>
        
        <table border="1">
            <tr>
                <th>Cabeçalho</th>
                <th>Outro Cabeçalho</th>
            </tr>

            <tr>
                <td>linha 1, célula 1</td>
                <td>linha 1, célula 2</td>
            </tr>
            <tr>
                <td>linha 2, célula 1</td>
                <td>linha 2, célula 2</td>
            </tr>
        </table>
    </body>
</html>