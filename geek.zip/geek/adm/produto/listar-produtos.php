<?php 
include_once '../classes/autoload.php';

$produtoDao = new ProdutoDao();
$lista = $produtoDao->select();
?>

<html>
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="assets/js/script.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"/>
        <link rel="sortcut icon" href="assets/img/icon.ico" type="image/x-icon"/>
        <meta charset="utf-8">
    <body>

    <section id="content">

            <table>
			<thead>
			<tr>
			<th>id</th>
			<th>nome</th>
			<th>categoria</th>
			<th>descrição</th>
			<th>unidades</th>
			<th>img</th>
			<th>Preço</th>
			</tr>
			</thead>
			<tbody>
                    <?php foreach($lista as $produtos): ?>
                 
					<tr>
							<td> <?php echo $produtos->getId(); ?></td>
                            <td> <?php echo $produtos->getNome(); ?></td>
                            <td> <?php echo $produtos->getCategoria(); ?></td>
                            <td> <?php echo $produtos->getDescricao(); ?></td>
                            <td> <?php echo $produtos->getUnidades(); ?></td>
                            <td> <?php echo $produtos->getImg(); ?></td>
                            <td> <?php echo $produtos->getPreco(); ?></td>
							
                        <td><button onclick="confirm('Deseja exclir este registro?') ? window.location='produto-deleta-ok.php?id=<?php echo $produtos->getId(); ?>' : stop = false;">  excluir </button> </td>
                        <td><button  onclick="window.location='produto-edita.php?id=<?php echo $produtos->getId(); ?>';" class="btn btn-outline btn-primary"> editar </button> </td>

                    <?php endforeach; ?> 
			</tbody>		
</table>
        </section>

    <footer>
        
    </footer>
    </body>
</html>
                                        