<?php
include_once '../classes/autoload.php';
//Verifica se veio tudo preenchido do formulário
if (isset($_GET['id']) && $_GET['id'] != "") {

    $categoria = new Categoria();
    $categoria->setId($_GET['id']);
    

    $categoriaDao = new categoriaDao();
    $categoriaDao->delete($categoria);
    
    header( "Refresh:5; url=categoria-lista.php", true, 303);
}
?>
<html>
<body>     

    <section id="contato">
        <h2> Sucesso ao deletar!</h2>
     </section>
    
    <footer> 
    </footer>
</body>
</html>