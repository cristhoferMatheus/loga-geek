<?php
include_once 'classes/autoload.php';

//Verifica se veio tudo preenchido do formulário
if (isset($_POST['nome']) && $_POST['nome'] != "" 
        && isset($_POST['email']) && $_POST['email'] != ""
        && isset($_POST['telefone']) && $_POST['telefone'] != ""
		&& isset($_POST['endereco']) && $_POST['endereco'] != ""
		&& isset($_POST['dtnasc']) && $_POST['dtnasc'] != ""
        && isset($_POST['senha']) && $_POST['senha'] != "") {

    $usuario = new Usuario();
    $usuario->setNome($_POST['nome']);
    $usuario->setSenha($_POST['senha']);
    $usuario->setEmail($_POST['email']);
    $usuario->setTelefone($_POST['telefone']);
    $usuario->setEndereco($_POST['endereco']);
    $usuario->setDtnasc($_POST['dtnasc']);

    $usuarioDao = new UsuarioDao();
    $usuarioDao->insert($usuario);
}
?>

<html>
<body> 


    <!-- FALE CONOSCO -->
    <section id="contato">
        <h2> Sucesso ao cadastrar!</h2>
     </section>
    
    <footer> 
    </footer>
</body>
</html>