<?php

class UsuarioDao extends Db implements InterfaceDao {

    private $table = 'usuario';

    public function insert($usuario) {
        $stmt = $this->conexao->prepare("INSERT INTO {$this->table} (nome, senha, email, telefone, endereco, dtnasc) VALUES (:nome, :senha, :email, :telefone, :endereco, :dtnasc)");

        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':senha', $usuario->getSenha());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':telefone', $usuario->getTelefone());
        $stmt->bindValue(':endereco', $usuario->getEndereco());
        $stmt->bindValue(':dtnasc', $usuario->getDtnasc());

        return $stmt->execute();
    }
    
    public function update($usuario) {
        $stmt = $this->conexao->prepare("UPDATE {$this->table} "
                . "SET nome=:nome, senha = :senha, email = :email, telefone = :telefone endereco = :endereco, dtnasc = :dtnasc WHERE id = :id;");

        $stmt->bindValue(':id', $usuario->getId());
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':senha', $usuario->getSenha());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':telefone', $usuario->getTelefone());
        $stmt->bindValue(':endereco', $usuario->getEndereco());
        $stmt->bindValue(':dtnasc', $usuario->getDtnasc());

        return $stmt->execute();
    }    

    public function delete($usuario) {
        $stmt = $this->conexao->prepare("DELETE FROM {$this->table} "
                . " WHERE id = :id");

        $stmt->bindValue(':id', $usuario->getId());
        
        return $stmt->execute();
    }

    public function select() {
        $stmt = $this->conexao->prepare("SELECT * FROM $this->table");
        $stmt->execute();

        $usuarios = array();

        while ($linha = $stmt->fetch()) {
            $usuario = new Usuario();
            $usuario->setNome($linha['nome']);
            $usuario->setSenha($linha['senha']);
            $usuario->setEmail($linha['email']);
            $usuario->setTelefone($linha['telefone']);
            $usuario->setTelefone($linha['endereco']);
            $usuario->setTelefone($linha['dtnasc']);
            $usuario->setId($linha['id']);

            $usuarios[] = $usuario;
        }
        return $usuarios;
    }

    public function selectById($usuario) {
        $stmt = $this->conexao->prepare("SELECT * FROM $this->table WHERE id = :id");
        
        $stmt->bindValue(':id', $usuario->getId());
        $stmt->execute();
        
        $linha = $stmt->fetch();

        $usuario = new Usuario();
        $usuario->setNome($linha['nome']);
        $usuario->setSenha($linha['senha']);
        $usuario->setEmail($linha['email']);
        $usuario->setTelefone($linha['telefone']);
        $usuario->setTelefone($linha['endereco']);
        $usuario->setTelefone($linha['dtnasc']);
        $usuario->setId($linha['id']);
        
        return $usuario;
    }
}
