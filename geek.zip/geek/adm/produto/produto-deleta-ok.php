<?php
include_once '../classes/autoload.php';
//Verifica se veio tudo preenchido do formulário
if (isset($_GET['id']) && $_GET['id'] != "") {

    $produto = new Produto();
    $produto->setId($_GET['id']);
    

    $produtoDao = new ProdutoDao();
    $produtoDao->delete($produto);
    
    header( "Refresh:5; url=produto-lista.php", true, 303);
}
?>
<html>
<body>     

    <section id="contato">
        <h2> Sucesso ao deletar!</h2>
     </section>
    
    <footer> 
    </footer>
</body>
</html>