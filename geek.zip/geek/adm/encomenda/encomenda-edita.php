<?php
include_once '../classes/autoload.php';

//Verifica se veio tudo preenchido do formulário
if (isset($_GET['id']) && $_GET['id'] != "") {

    $encomenda = new Encomenda();
    $encomenda->setId($_GET['id']);

    $encomendaDao = new EncomendaDao();
    $encomendaData = $encomendaDao->selectById($encomenda);
    
}
?>

<html>
<body> 

    <section id="contato">
        <h2> Cadastre a Encomenda:</h2>
        <div class="areaform">
            <form method="post" action="produto-edita-ok.php">
            <input type="hidden" name="id" value="<?php echo $produtoData->getId(); ?>" >
                <label for="nPed">Numero de pedidos:</label>
                <input type="text" id="Nped" name="Nped" placeholder="Insira o numero de pedidos">

                <label for="nomeS">Nome do Solicitante:</label>
                <input type="text" id="NomeS" name="NomeS" placeholder="Insira o nome do solicitante">

                <label for="estado">Estado:</label>
                <input type="text" id="estado" name="estado" placeholder="Insira o estado do pedinte">

				<label for="cidade">Cidade:</label>
                <input type="number" id="cidade" name="cidade" placeholder="Insira a cidade do solicitante">

                <label for="endereco">Endereco:</label>
                <input type="text" id="endereco" name="endereco" placeholder="insira o endereço do pedinte">
				
             <button class="button" type="submit"> Confirmar</button>
            </form>
        </div>
     </section>
    
    <footer> 
   </footer>
</body>
</html>