﻿<?php 
include_once '../classes/autoload.php';

$encomendaDao = new EncomendaDao();
$lista = $encomendaDao->select();
?>

<header >
 <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="assets/js/script.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"/>
        <link rel="sortcut icon" href="assets/img/icon.ico" type="image/x-icon"/>
        <meta charset="utf-8">
</header>

<div class="conteudo" style="margin-top:138px;">
    <div >
        <div >
            <div >
                Pedidos de Encomendas
            </div>

            <div >
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>  
                            <th>N° de Pedidos</th>
                            <th>Nome do Solicitante</th>
                            <th>Estado</th>
							<th>Cidade</th>
							<th>Endereço</th>                             
                        </tr>
                    </thead>
                    <tbody>
                            <?php foreach ($lista as $encom): ?> 
                                    <td><?php echo $encom->getId(); ?></td>
                                    <td><?php echo $encom->getNped(); ?></td>
                                    <td><?php echo $encom->getNomeS(); ?></td>
                                    <td><?php echo $encom->getEstado(); ?></td>
                                    <td><?php echo $encom->getCidade(); ?></td>
                                    <td><?php echo $encom->getEndereco(); ?></td>
                                  
                                    <td><button onclick="confirm('Deseja exclir este registro?') ? window.location='encomenda-deleta-ok.php?id=<?php echo $produtos->getId(); ?>' : stop = false;">  excluir </button> </td>
									<td><button  onclick="window.location='encomenda-edita.php?id=<?php echo $produtos->getId(); ?>';" class="btn btn-outline btn-primary"> editar </button> </td>
									                            

                            <?php endforeach; ?>   
                    </tbody>
                </table>

            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>

    <!-- /.row -->

</div>
<style>
table{
border:solid;
background-color:#632e2e;
color:#ffffff;
}

#check{
	display:none;
}
#icone{
	cursor:pointer;
	padding:32px;
	position:absolute;
	z-index:1;
	top:-20px;
	left:13px;
}
.menu{
	background-color:#333;
	height:100%;
	width:200px;
	position:absolute;
	transition:all .2s linear;
	left:-200px; 
	top:-1px;
	
}
nav{
		width:100%;
		position:absolute;
		top:150px;
}
nav a{
	text-decoration:none;
}
.menu--link{
	background-color:#494950;
	padding:20px;
	font-family:arial;
	font-size:12pt;
	transition:all .2s linear;
	color:f4f4f9;
	border-bottom:2px solid #222;
	opacity:0;
	margin-top:200px;
	
}
.menu--link:hover{
		background-color:#050542;
}
#check:checked ~ .menu{
	transform:translateX(200px);
}
#check:checked ~ .menu nav a .menu--link{
	opacity:1;
	margin-top:17px;
	transition-delay:.2s;
}

.imgI{
	height:100px;
	width:100px;
	border-radius: 50%;
}

body{
background-color:#b9b9b9;
}
</style>