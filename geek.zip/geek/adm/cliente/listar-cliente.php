<?php 
include_once '../classes/autoload.php';

$clienteDao = new ClienteDao();
$lista = $clienteDao->select();

print_r($lista);
?>

<html>
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="assets/js/script.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"/>
        <link rel="sortcut icon" href="assets/img/icon.ico" type="image/x-icon"/>
        <meta charset="utf-8">
    <body>

    <section id="content">

            <table>
			<thead>
			<tr>
			<th>id</th>
			<th>nome</th>
			<th>Sobrenome</th>
			<th>email</th>
			<th>cpf</th>
			<th>cidade</th>
			<th>estado</th>
			<th>login</th>
			<th>senha</th>
			</tr>
			</thead>
			<tbody>
                    <?php foreach($lista as $clientes): ?>
                 
					<tr>
							<td> <?php echo $clientes->getId(); ?></td>
                            <td> <?php echo $clientes->getNome(); ?></td>
                            <td> <?php echo $clientes->getSnome(); ?></td>
                            <td> <?php echo $clientes->getEmail(); ?></td>
                            <td> <?php echo $clientes->getCpf(); ?></td>
                            <td> <?php echo $clientes->getCidade(); ?></td>
                            <td> <?php echo $clientes->getEstado(); ?></td>
                            <td> <?php echo $clientes->getLogin(); ?></td>
                            <td> <?php echo $clientes->getSenha(); ?></td>
							
                        <td><button onclick="confirm('Deseja exclir este registro?') ? window.location='cliente-deleta-ok.php?id=<?php echo $clientes->getId(); ?>' : stop = false;">  excluir </button> </td>
                        <td><button  onclick="window.location='cliente-edita.php?id=<?php echo $clientes->getId(); ?>';" class="btn btn-outline btn-primary"> editar </button> </td>

                    <?php endforeach; ?> 
			</tbody>		
</table>
        </section>

    <footer>
        
    </footer>
    </body>
</html>
                                        