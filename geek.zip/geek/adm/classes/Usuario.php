<?php

class Usuario {
    private $id;
    private $nome;
    private $email;
    private $telefone;
    private $endereco;
    private $senha;
	  
    function getId() {
        return $this->id;
    }

    function getNome() {
        return $this->nome;
    }

    function getSenha() {
        return $this->senha;
    }

    function getEmail() {
        return $this->email;
    }

    function getTelefone() {
        return $this->telefone;
    }
	
	function getEndereco() {
        return $this->endereco;
    }


    function setId($id) {
        $this->id = $id;
    }

    function setNome($nome) {
        $this->nome = $nome;
    }

    function setSenha($senha) {
        $this->senha = $senha;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setTelefone($telefone) {
        $this->telefone = $telefone;
    }
	
	function setEndereco($endereco) {
        $this->endereco = $endereco;
    }

}