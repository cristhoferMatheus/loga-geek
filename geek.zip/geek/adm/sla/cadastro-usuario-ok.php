<?php
include_once 'classes/Usuario.php';
include_once 'classes/UsuarioDao.php';


    
    $usuario = new Usuario();
    $usuario->setEmail($_POST['email']);
    $usuario->setPassword($_POST['password']);
    $usuario->setUsername($_POST['username']);

    $usuarioDao = new UsuarioDao();
    $result = $usuarioDao->insert($usuario);
    
    if($result){
        echo "Usuário cadastrado com sucesso!";        
    }
    



