<?php 
$listaNoticia = $data['listaNoticia'];
//echo "<pre>";
//var_dump($listaNoticia);
//echo "</pre>";
?>
<header style="height:100px"></header>

<section class="masthead2" class="bg-primary" >
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto" >
                <center> <h1 >News</h1> </center>
                <br>
                <ul>
                    <?php if($listaNoticia) :?>
                    <center><?php foreach ($listaNoticia as $noticia): ?>
                        <lu>
                            
                            <a href="<?php echo $this->url ?>News/viewNews/<?php echo $noticia->getIdnoticia() ?>">
                                <?php echo $noticia->getTitulo() ?><br>
                            </a>
                        </lu>
                        <br>
                    <?php endforeach; ?></center>
                    <?php endif; ?>    
                </ul>
            </div>
        </div>
    </div>
</section>
