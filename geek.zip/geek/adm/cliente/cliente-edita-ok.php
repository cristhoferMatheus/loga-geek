<?php
include_once '../classes/autoload.php';

if (isset($_POST['nome']) && $_POST['nome'] != "" 
        && isset($_POST['Snome']) && $_POST['Snome'] != ""
        && isset($_POST['email']) && $_POST['email'] != ""
		&& isset($_POST['cpf']) && $_POST['cpf'] != ""
        && isset($_POST['cidade']) && $_POST['cidade'] != ""
		&& isset($_POST['estado']) && $_POST['estado'] != ""
        && isset($_POST['login']) && $_POST['login'] != ""
        && isset($_POST['senha']) && $_POST['senha'] != "") {

    $cliente = new Cliente();
    $cliente->setNome($_POST['nome']);
    $cliente->setSnome($_POST['Snome']);
    $cliente->setEmail($_POST['email']);
    $cliente->setCpf($_POST['cpf']);
	$cliente->setCidade($_POST['cidade']); 
	$cliente->setEstado($_POST['estado']); 
	$cliente->setLogin($_POST['login']); 
	$cliente->setSenha($_POST['senha']); 

    $clienteDao = new ClienteDao();
    $clienteDao->update($cliente);
}
?>

<html>    
<body> 
    
    <section id="contato">
        <h2> Sucesso ao editar!</h2>
     </section>
    
</body>
    <footer> 
    </footer>
</html>