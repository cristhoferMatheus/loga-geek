<?php
include_once '../classes/autoload.php';

if (isset($_POST['action']) && $_POST['action'] != "" 
        && isset($_POST['livros']) && $_POST['livros'] != ""
        && isset($_POST['acessorios']) && $_POST['acessorios'] != ""
        && isset($_POST['roupas']) && $_POST['roupas'] != "") {

    $categoria = new Categoria();
    $categoria->setId($_POST['id']);
    $categoria->setAction($_POST['action']);
    $categoria->setLivros($_POST['livros']);
    $categoria->setAcessorios($_POST['acessorios']);
    $categoria->setRoupas($_POST['roupas']);

    $categoriaDao = new CategoriaDao();
    $categoriaDao->update($categoria);
}
?>

<html>    
<body> 
    
    <section id="contato">
        <h2> Sucesso ao editar!</h2>
     </section>
    
</body>
    <footer> 
    </footer>
</html>