<html>
    <head></head>
    
<body> 

    <section id="contato">
        <h2> Cadastre-se:</h2>
        <div class="areaform">
            <form method="post" action="cadastro-encomenda-ok.php"> 
                <label for="nPed">Numero de Pedido:</label>
                <input type="text" id="nPed" name="nPed" placeholder="Insira o numero de pedidos">

                <label for="nomeS">Nome do Solicitante:</label>
                <input type="text" id="nomeS" name="nomeS" placeholder="Insira o nome do solicitante">

                <label for="estado">Estado:</label>
                <input type="text" id="estado" name="estado" placeholder="Insira o estado do solicitante">

				<label for="cidade">Cidade:</label>
                <input type="text" id="cidade" name="cidade" placeholder="Insira a cidade do pedinte">

                <label for="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" placeholder="insira o endereço do pedinte">
				
				<button class="button" type="submit"> Confirmar</button>
            </form>
        </div>
     </section>
 
    <footer>  </footer>
</body>
</html>