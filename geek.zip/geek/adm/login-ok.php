<?php
session_start();
include_once 'classes/autoload.php';
include_once 'classes/UsuarioDao.php';

if (isset($_POST['senha']) && isset($_POST['email']) 
        && $_POST['senha'] != "" && $_POST['email'] != "") {
    
	
	$usuario = new Usuario();
    $usuario->setEmail($_POST['email']);
    $usuario->setSenha($_POST['senha']);

    $login = new Login();
    $login = $login->verificaLogin($usuario);
    
    if($login){
        header('Location:usuario-lista.php');
    } else {
        header('Location:login.php');
    }
    
} else {
    $msg = "Preencha todos os campos";
    echo $msg;
}
?>